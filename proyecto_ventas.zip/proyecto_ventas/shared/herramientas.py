"""Funciones de consola compartidas por todas las vistas."""


def imprimir_titulo(texto):
    print("\n" + "=" * 46)
    print(f"  {texto}")
    print("=" * 46)


def imprimir_exito(texto):
    print(f"✅ {texto}")


def imprimir_error(texto):
    print(f"❌ {texto}")


def imprimir_info(texto):
    print(f"ℹ️  {texto}")


def confirmar(pregunta):
    """Pregunta s/n. Devuelve True solo si responde 's' o 'si'."""
    respuesta = input(f"{pregunta} (s/n): ").strip().lower()
    return respuesta in ("s", "si", "sí")

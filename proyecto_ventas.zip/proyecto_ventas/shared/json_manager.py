"""Lectura y escritura de archivos JSON (la usan todos los controladores)."""
import json
import os


class GestorJSON:
    """Guarda y lee una lista de diccionarios en un archivo .json."""

    def __init__(self, ruta):
        self.__ruta = ruta
        carpeta = os.path.dirname(ruta)
        if carpeta:
            os.makedirs(carpeta, exist_ok=True)
        if not os.path.exists(ruta):
            self.guardar([])

    @property
    def ruta(self):
        return self.__ruta

    def leer(self):
        """Devuelve la lista guardada; si el archivo está vacío o dañado, []."""
        try:
            with open(self.__ruta, "r", encoding="utf-8") as archivo:
                datos = json.load(archivo)
            return datos if isinstance(datos, list) else []
        except (FileNotFoundError, json.JSONDecodeError):
            return []

    def guardar(self, registros):
        """Escribe la lista completa. Devuelve True si salió bien."""
        try:
            with open(self.__ruta, "w", encoding="utf-8") as archivo:
                json.dump(registros, archivo, ensure_ascii=False, indent=2)
            return True
        except OSError:
            return False

# Sistema de ventas · CRUD en Python con POO (Guía 2, Parte 3)

## Cómo ejecutarlo
Desde esta carpeta:

    python main.py

Necesita Python 3.8 o superior. No requiere instalar nada.

## Estructura
    proyecto_ventas/
    ├── main.py                  Vistas: MenuCRUD, MenuVentas, MenuPrincipal
    ├── views.py                 Controladores: CrudBase (abstracta), Cliente, Producto, Venta
    ├── models.py                Modelos: ModeloBase, Persona, Cliente, Producto, DetalleVenta, Venta
    ├── models_academico.py      TAREA: modelos del negocio académico (ya escritos)
    ├── views_academico.py       TAREA: controladores académicos (con TODO por resolver)
    ├── shared/
    │   ├── json_manager.py      GestorJSON (leer / guardar)
    │   └── herramientas.py      Funciones de consola
    └── data/                    Los JSON se guardan aquí

## Para probar (en este orden)
1. Clientes: crear dos clientes.
2. Productos: crear "teclado" a 25.50 con stock 10 y "mouse" a 12 con stock 3.
3. Intentar crear otro "Teclado": debe rechazarlo.
4. Ventas: registrar una venta con 2 teclados y 1 mouse.
5. Volver a Productos: el stock bajó.
6. Ventas, opción 7: ver la factura.
7. Intentar vender 99 mouse: "Stock insuficiente".

## Nota
shared/ no venía en el documento (la guía dice que es igual al de la parte 2),
así que se reescribió con la misma interfaz que usa el proyecto.
La tarea académica (views_academico.py) aún no está conectada a main.py.
